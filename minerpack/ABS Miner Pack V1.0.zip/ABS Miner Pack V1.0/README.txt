
ABS Miner Pack V1.0 - User Guide

Edit pool file desired RUN - ABS - 'Pool name' file with notepad
Edit the wallet address (this is currently set to the community fund address).
Save and exit
Run the pool file.

If you wish to look at fees, the pool addresses are:
 
https://www.gos.cx
http://www.phi-phi-pool.com
https://coin-miners.info
https://www.starpool.biz
http://zergpool.com

Many thanks to blake410 for helping with this miner pack.